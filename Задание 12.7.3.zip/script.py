money = float(input("Введите сумму вклада: "))

per_cent = {'ТКБ': 5.6, 'СКБ': 5.9, 'ВТБ': 4.28, 'СБЕР': 4.0}

print("deposit = [%d, %d, %d, %d]" % (per_cent['ТКБ'] * money / 100,
                                      per_cent['СКБ'] * money / 100,
                                      per_cent['ВТБ'] * money / 100,
                                      per_cent['СБЕР'] * money / 100))

per_cent_list = list(per_cent.values())
per_cent_list.sort(reverse=True)
max_per_cent = per_cent_list[0]

print("Максимальная сумма, которую вы можете заработать — %d" % (max_per_cent * money / 100))
